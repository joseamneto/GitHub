1)Check if your Sitecore is 8.1 and Update 1
2)BACKUP YOUR FILE sitecore\shell\client\Sitecore\ExperienceEditor\ExperienceEditor.js
3)Replace  the "ExperienceEditor.js" with the version on this zip
4)Run Experience Editor(CTRL + F5) may be necessary to clear the cache